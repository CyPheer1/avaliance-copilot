"""Tests for proposal structure generation."""

from unittest.mock import patch

from app.generation.prompts import INSUFFICIENT_INFORMATION
from app.generation.service import generate_rfp_structure
from app.schemas import RfpRequest, SimilarMission
from app.settings import Settings

TOKEN = "test-internal-token-123456"


def _settings() -> Settings:
    return Settings(
        internal_token=TOKEN,
        database_url="postgresql://test:test@localhost:5432/test",
    )


def test_rfp_uses_strict_sections_and_grounded_missions():
    request = RfpRequest(
        description="Moderniser une plateforme bancaire",
        missions=[
            SimilarMission(
                id=7,
                title="Modernisation bancaire",
                sector="banque",
                mission_type="modernisation applicative",
                technologies=["Java", "Spring Boot"],
                year=2024,
                summary="Modernisation progressive d'une plateforme.",
                similarity_score=0.91,
            )
        ],
    )
    with patch(
        "app.generation.service.generate_text",
        return_value="# Proposition\n\n## Contexte",
    ) as generate_text:
        response = generate_rfp_structure(request, _settings())

    assert response.rfp_structure.startswith("# Proposition")
    prompt = generate_text.call_args.args[0]
    assert "Risques & mitigation" in prompt
    assert "Ne pas inventer de client réel" in prompt
    assert "[Mission 1] Modernisation bancaire" in prompt
    assert generate_text.call_args.kwargs["max_tokens"] == 400


def test_rfp_does_not_call_ollama_without_missions():
    request = RfpRequest(description="Besoin inconnu", missions=[])
    with patch("app.generation.service.generate_text") as generate_text:
        response = generate_rfp_structure(request, _settings())

    assert response.rfp_structure == INSUFFICIENT_INFORMATION
    generate_text.assert_not_called()