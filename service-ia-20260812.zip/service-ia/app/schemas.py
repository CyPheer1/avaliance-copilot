"""Pydantic v2 schemas for service-ia request/response models."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

CorpusScope = Literal["PDF", "MISSION", "LEGACY_SYNTHETIC"]

# ---------------------------------------------------------------------------
# /embed
# ---------------------------------------------------------------------------
class EmbedRequest(BaseModel):
    texts: list[str] = Field(..., min_length=1, description="Raw texts to encode into BGE-M3 vectors")


class EmbedResponse(BaseModel):
    embeddings: list[list[float]]
    dimension: int
    count: int


# ---------------------------------------------------------------------------
# /ingest
# ---------------------------------------------------------------------------
class IngestMissionDocument(BaseModel):
    chunk_index: int
    kind: str
    content: str = Field(..., min_length=1)


class IngestMissionRequest(BaseModel):
    id: str
    title: str
    sector: str
    mission_type: str
    technologies: list[str]
    year: int
    referent_tag: str | None = None
    summary: str
    documents: list[IngestMissionDocument] = Field(..., min_length=1)


class IngestRequest(BaseModel):
    missions: list[IngestMissionRequest] = Field(..., min_length=1)
    chunk_max_characters: int = Field(default=512, ge=64)
    chunk_overlap_characters: int = Field(default=64, ge=0)


class IngestResponse(BaseModel):
    missions_inserted: int
    chunks_inserted: int
    chunks_with_embeddings: int


# ---------------------------------------------------------------------------
# /retrieve
# ---------------------------------------------------------------------------
class RetrieveRequest(BaseModel):
    query: str = Field(..., min_length=1)
    top_k: int = Field(default=5, ge=1, le=50)
    sector: str | None = None
    mission_type: str | None = None
    year: int | None = None
    corpus_scope: CorpusScope = Field(default="PDF")
    request_id: str | None = None


class RetrievedChunk(BaseModel):
    chunk_id: int
    mission_id: int | None = None
    mission_title: str | None = None
    document_id: int | None = None
    document_name: str | None = None
    page: int | None = None
    sector: str | None = None
    mission_type: str | None = None
    corpus_scope: CorpusScope
    request_id: str | None = None
    content: str
    score: float  # Backward-compatible alias for the rank-only RRF score.
    rrf_score: float | None = None
    relevance_score: float | None = None
    vector_score: float | None = None
    text_score: float | None = None


class RetrieveResponse(BaseModel):
    query: str
    chunks: list[RetrievedChunk]
    total_found: int


# ---------------------------------------------------------------------------
# /similar
# ---------------------------------------------------------------------------
class SimilarRequest(BaseModel):
    description: str = Field(..., min_length=1)
    sector: str | None = None
    mission_type: str | None = None
    top_k: int = Field(default=5, ge=1, le=50)


class SimilarMission(BaseModel):
    id: int
    title: str
    sector: str
    mission_type: str
    technologies: list[str]
    year: int
    summary: str
    similarity_score: float


class SimilarResponse(BaseModel):
    missions: list[SimilarMission]


# ---------------------------------------------------------------------------
# /generate
# ---------------------------------------------------------------------------
class GenerateRequest(BaseModel):
    query: str = Field(..., min_length=1)
    request_id: str | None = None
    chunks: list[RetrievedChunk]


class EvidenceItem(BaseModel):
    evidence_id: int = Field(..., ge=1)
    chunk_id: int
    mission_id: int | None = None
    mission_title: str | None = None
    document_id: int | None = None
    document_name: str | None = None
    page: int | None = None
    corpus_scope: CorpusScope
    request_id: str | None = None
    content: str
    source_start: int = Field(..., ge=0)
    source_end: int = Field(..., ge=0)


class Citation(BaseModel):
    citation_id: str
    chunk_id: int
    mission_id: int | None = None
    mission_title: str | None = None
    document_id: int | None = None
    document_name: str | None = None
    page: int | None = None
    corpus_scope: CorpusScope
    request_id: str | None = None
    content: str
    score: float  # Backward-compatible alias for the rank-only RRF score.
    rrf_score: float | None = None
    relevance_score: float | None = None
    source_index: int | None = Field(default=None, ge=1)


class EvidenceSpan(BaseModel):
    """A validated factual claim and its exact source range in selected evidence."""

    evidence_id: int = Field(..., ge=1)
    chunk_id: int
    quote: str = Field(..., min_length=1)
    source_start: int = Field(..., ge=0)
    source_end: int = Field(..., ge=0)
    answer_start: int = Field(..., ge=0)
    answer_end: int = Field(..., ge=0)


class GenerateResponse(BaseModel):
    answer: str
    citations: list[Citation]
    confidence: float = Field(..., ge=0.0, le=1.0)
    evidence: list[EvidenceItem] = Field(default_factory=list)
    evidence_spans: list[EvidenceSpan] = Field(default_factory=list)
    validation_passed: bool = False
    diagnostic: Literal[
        "NO_RELEVANT_EVIDENCE",
        "UNSUPPORTED_ANSWER",
        "INVALID_CITATION_FORMAT",
    ] | None = None


# ---------------------------------------------------------------------------
# /rfp
# ---------------------------------------------------------------------------
class RfpRequest(BaseModel):
    description: str = Field(..., min_length=1)
    missions: list[SimilarMission]


class RfpResponse(BaseModel):
    rfp_structure: str
