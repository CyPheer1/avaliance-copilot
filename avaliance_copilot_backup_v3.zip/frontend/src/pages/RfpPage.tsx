import { useState } from 'react'
import type { FormEvent } from 'react'
import { Check, Copy, Download, FilePenLine, Sparkles } from 'lucide-react'
import { useMutation } from '@tanstack/react-query'
import ReactMarkdown from 'react-markdown'
import { api, errorMessage } from '../api/client.ts'
import { ErrorState, ProcessingState } from '../components/AsyncState.tsx'
import { PageHeader } from '../components/PageHeader.tsx'

export function RfpPage() {
  const [description, setDescription] = useState('')
  const [sector, setSector] = useState('')
  const [missionType, setMissionType] = useState('')
  const [copied, setCopied] = useState(false)
  const generation = useMutation({ mutationFn: () => api.generateRfp({ description, query: description, sector: sector || undefined, missionType: missionType || undefined, topK: 5 }) })

  const submit = (event: FormEvent) => { event.preventDefault(); generation.mutate() }
  const copy = async () => { if (!generation.data) return; await navigator.clipboard.writeText(generation.data.rfpStructure); setCopied(true); window.setTimeout(() => setCopied(false), 1600) }
  const download = () => {
    if (!generation.data) return
    const url = URL.createObjectURL(new Blob([generation.data.rfpStructure], { type: 'text/markdown;charset=utf-8' }))
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'structure-proposition.md'; anchor.click(); URL.revokeObjectURL(url)
  }

  return (
    <div className="page">
      <PageHeader eyebrow="Avant-vente" title="Construire une proposition" description="Générez un document de réponse structuré, exploitable et appuyé sur les missions comparables disponibles." />
      <form className="rfp-brief" onSubmit={submit}>
        <div className="rfp-brief__number">01</div>
        <div className="rfp-brief__body">
          <label htmlFor="rfp-description">Brief client ou cahier des charges</label>
          <textarea id="rfp-description" rows={7} value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Décrivez le contexte, les objectifs, le périmètre attendu, les contraintes, les parties prenantes et les technologies envisagées…" required />
          <p className="rfp-guidance">Plus le brief est précis, plus la synthèse, les livrables, la démarche, les jalons et les questions de cadrage seront pertinents. Les références restent citées et les recommandations sont explicitement distinguées des faits établis.</p>
          <div className="filter-row filter-row--open">
            <label>Secteur<input value={sector} onChange={(event) => setSector(event.target.value)} placeholder="Ex. banque" /></label>
            <label>Type de mission<input value={missionType} onChange={(event) => setMissionType(event.target.value)} placeholder="Ex. migration cloud" /></label>
          </div>
          <button className="button button--primary" type="submit" disabled={generation.isPending}><Sparkles size={18} />Générer la proposition professionnelle</button>
        </div>
      </form>
      {generation.isPending && <ProcessingState label="Analyse des références et rédaction de la proposition" />}
      {generation.isError && <ErrorState message={errorMessage(generation.error)} />}
      {!generation.data && !generation.isPending && <section className="rfp-empty"><FilePenLine size={24} /><h2>Le document de travail apparaîtra ici.</h2><p>Les missions comparables resteront visibles pour faciliter la relecture, l’alignement et la vérification.</p></section>}
      {generation.data && (
        <section className="rfp-result reveal">
          <aside className="reference-list">
            <div className="section-heading"><span>Missions comparables</span><strong>{generation.data.similarMissions.length.toString().padStart(2, '0')}</strong></div>
            {generation.data.similarMissions.map((mission, index) => {
              const similarity = mission.similarityScore ?? mission.similarity_score ?? 0
              return <article key={mission.id} className="reference-item"><span>{String(index + 1).padStart(2, '0')}</span><div><h3>{mission.title}</h3><p>{mission.sector} · {mission.missionType ?? mission.mission_type} · {mission.year}</p><div className="tech-list">{mission.technologies.map((technology) => <i key={technology}>{technology}</i>)}</div></div><strong>{Math.round(similarity * 100)}%</strong></article>
            })}
          </aside>
          <article className="rfp-document">
            <header><div><span className="eyebrow">Document généré</span><h2>Proposition de réponse</h2></div><div className="document-actions"><button className="icon-button" type="button" onClick={copy} title="Copier" aria-label="Copier">{copied ? <Check size={18} /> : <Copy size={18} />}</button><button className="icon-button" type="button" onClick={download} title="Télécharger" aria-label="Télécharger"><Download size={18} /></button></div></header>
            <span className="sr-only" role="status">{copied ? 'Structure de proposition copiée.' : ''}</span>
            <div className="markdown-document"><ReactMarkdown>{generation.data.rfpStructure}</ReactMarkdown></div>
          </article>
        </section>
      )}
    </div>
  )
}