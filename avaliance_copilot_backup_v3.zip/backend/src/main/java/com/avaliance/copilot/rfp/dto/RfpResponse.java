package com.avaliance.copilot.rfp.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * Response body for POST /api/rfp/generate.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RfpResponse {

    /** The generated RFP structure text */
    private String rfpStructure;

    /** List of similar missions used as basis */
    private List<Map<String, Object>> similarMissions;
}
