package com.avaliance.copilot.rfp.service;

import com.avaliance.copilot.audit.service.AuditService;
import com.avaliance.copilot.config.enums.AuditAction;
import com.avaliance.copilot.rfp.dto.RfpRequest;
import com.avaliance.copilot.rfp.dto.RfpResponse;
import com.avaliance.copilot.search.service.IaClientService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Orchestration service for RFP structure generation.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RfpService {

    private final IaClientService iaClientService;
    private final AuditService auditService;

    @SuppressWarnings("unchecked")
    public RfpResponse generate(RfpRequest request) {
        long startTime = System.currentTimeMillis();
        String status = "SUCCESS";
        try {
            Map<String, Object> similarRequest = new LinkedHashMap<>();
            similarRequest.put("description", request.getDescription());
            if (request.getSector() != null) similarRequest.put("sector", request.getSector());
            if (request.getMissionType() != null) similarRequest.put("mission_type", request.getMissionType());
            if (request.getTopK() != null) similarRequest.put("top_k", request.getTopK());

            Map<String, Object> similarResponse = iaClientService.similar(similarRequest);

            // Step 2: Generate RFP structure using similar missions
            Map<String, Object> rfpRequest = new LinkedHashMap<>();
            rfpRequest.put("description", request.getDescription());
            rfpRequest.put("missions", similarResponse.get("missions"));

            Map<String, Object> rfpResponse = iaClientService.rfp(rfpRequest);

            // Build response
            List<Map<String, Object>> missions = (List<Map<String, Object>>) similarResponse.get("missions");

            return RfpResponse.builder()
                    .rfpStructure((String) rfpResponse.get("rfp_structure"))
                    .similarMissions(missions != null ? missions : List.of())
                    .build();

        } catch (Exception e) {
            status = "ERROR";
            throw e;
        } finally {
            long duration = System.currentTimeMillis() - startTime;
            auditService.log(AuditAction.GENERATE_RFP, request.getDescription(), status, duration);
        }
    }
}
