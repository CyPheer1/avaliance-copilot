"""Tests for proposal structure generation."""

from unittest.mock import patch

from app.generation.prompts import INSUFFICIENT_INFORMATION
from app.generation.service import generate_rfp_structure
from app.schemas import RfpRequest, SimilarMission
from app.settings import Settings

TOKEN = "test-internal-token-123456"


def _settings() -> Settings:
    return Settings(
        internal_token=TOKEN,
        database_url="postgresql://test:test@localhost:5432/test",
    )


def test_rfp_uses_strict_sections_and_grounded_missions():
    request = RfpRequest(
        description="Moderniser une plateforme bancaire",
        missions=[
            SimilarMission(
                id=7,
                title="Modernisation bancaire",
                sector="banque",
                mission_type="modernisation applicative",
                technologies=["Java", "Spring Boot"],
                year=2024,
                summary="Modernisation progressive d'une plateforme.",
                similarity_score=0.91,
            )
        ],
    )
    with patch(
        "app.generation.service.generate_text",
        return_value="# Proposition\n\n## Contexte",
    ) as generate_text:
        response = generate_rfp_structure(request, _settings())

    assert response.rfp_structure.startswith("# Proposition")
    prompt = generate_text.call_args.args[0]
    assert "Expert IT & Stratégie Consultant senior" in prompt
    assert "1. Synthèse Exécutive" in prompt
    assert "2. Compréhension du Contexte et des Enjeux" in prompt
    assert "3. Approche et Architecture Proposée" in prompt
    assert "4. Méthodologie et Démarche Projet" in prompt
    assert "5. Gouvernance et Équipe" in prompt
    assert "6. Facteurs Clés de Succès" in prompt
    assert "prix et budgets sont exclus" in prompt
    assert "[Réf. M<n>]" in prompt
    assert "Ne pas inventer de client réel" in prompt
    assert "[Mission 1] Modernisation bancaire" in prompt
    assert "Année : 2024" in prompt
    assert generate_text.call_args.kwargs["max_tokens"] == 2000


def test_rfp_does_not_call_ollama_without_missions():
    request = RfpRequest(description="Besoin inconnu", missions=[])
    with patch("app.generation.service.generate_text") as generate_text:
        response = generate_rfp_structure(request, _settings())

    assert response.rfp_structure == INSUFFICIENT_INFORMATION
    generate_text.assert_not_called()